const http = require('http');
const nodemailer = require('nodemailer');
const fs = require('fs');

const createwriter = require('csv-writer').createObjectCsvWriter; 
const writer = createwriter({
    path: 'user.csv',
    header: [
        {id: 'user', title: 'User'},
        {id: 'pass', title: 'Pass'},
        {id: 'reg_date', title: 'Register Date'},
    ]
})

var server = http.createServer(function(request, response) {

    if (request.method == 'POST') {
        var body = '';
        request.on('data', function (data) {
            body += data;
        });
        request.on('end', function () {
            try {
                var post = JSON.parse(body);

                var data = [
                    {
                        user: post.email,
                        pass: generatePass(),
                        reg_date: new Date().getTime()
                    }
                ]

                Promise.resolve().then(function(){writer.writeRecords(data).then(function(){ console.log('Entry added to the CSV file user.csv') })})

                resp = sendMail(post.email);

                response.writeHead(200, {"Content-Type": "application/json"});
                response.end(JSON.stringify({ msg : resp}));

                return;
            }catch (err){
                response.writeHead(500, {"Content-Type": "text/plain"});
                response.write("Bad Post Data.  Is your data a proper JSON?\n");
                response.end();
                return;
            }
        });
    }



});
server.listen(3000, function(){
    console.log('Listening on port 3000')
});

function sendMail(email){
    var tp = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: "u16099860@tuks.co.za",
            pass: "Incorrect123!"
        }
    })

    info = tp.sendMail({
        from: 'u16099860@tuks.co.za', // sender address
        to: email, // list of receivers
        subject: "Sandwico Firewatch Account details", // Subject line
        text: "Hello world?", // plain text body
        html: "<b>Hello world?</b>" // html body
    });

    return 'Success: Mail has been sent!';
}

function generatePass(){
    return Math.random().toString(36).slice(-8);
}

